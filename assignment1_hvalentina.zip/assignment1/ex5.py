a = int(input("input number a\n"))
b = int(input("input number b\n"))
c = int(input("input number c\n"))

if ((a <= b + c) and (b <= a + c) and (c <= b + a)):
    print("triangle inequality valid")
    if (a == b == c):
        print("equilateral")

    elif ((a == b) or (a == c) or (b == c)):
        print("isoscleces")

    else:
        print("scalene")
else:
    print("INVALID INPUT, try again")





