f0 = 0
f1 = 1
fn = 1

number = int(input())
string = []

while f0 < number:
    string.append(f0)
    #print(f0)
    fn = f0 + f1
    f0 = f1
    f1 = fn

print(*string)


