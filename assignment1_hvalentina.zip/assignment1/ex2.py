word = input()
drow = []

#a
i = int(len(word))

while i > 0:
    drow.append(word[i-1])
    #print(word[i-1])
    i -= 1

print(*drow)

#b
print(word[::-1])




