int = int(input())
#x = oct(int)
str = []


#print(x[2:])

i = 0
j = int

while 8**i <= int:
    str.append(j%8)
    #print(j%8)
    j //= 8
    i += 1

print(*str[::-1])

#a

float = float(input())
str2 = []
k = 0
l = float

while 8**k <= float:
    str2.append(l%8)
    #print(j%8)
    l /= 8
    k += 1

print(*str2[::-1])

