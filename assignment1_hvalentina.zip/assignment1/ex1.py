name=input("Please input your name: ")

print("Hi",name,"\b! Nice to meet you!\nWelcome to the Programing Course!")

