number = int(input())

i = 0
print(i)

while i <= number:

    if(i%3 != 0):
        print(i)
    i += 1
